-=            Cartoon glove       	=-
-=        Modeled by 3DUA (aka Modeller, aka Alessandro.3mer)     =-
-=          Alexander Masliukivaky 	=-
-=	Alessandro.3mer@gmail.com         =-
-=               01.24.2004 ----updated 8 Dec 2009     =-

Cartoon gloves modelled and rendered in 3DMAX5 and then exported in:

-=Hi poly=-
Vertices:  2146
Polygons: 1072

-=Low poly =-
Vertices: 538
Faces: 256


My support by mail: alessandro.3mer@gmail.com. 