package min3d;

public class Min3d 
{
	public static final String TAG = "Min3D";
	
	/*
	 * Project homepage: 	http://code.google.com/p/min3d
	 * License:				MIT
	 * 
	 * Author: 				Lee Felarca
	 * Website:				http://www.zeropointnine.com/blog
	 *
	 * Author: 				Dennis Ippel
	 * Author blog:			http://www.rozengain.com/blog/
	 */
}
